export interface FilterRepresentative {
  readonly color: string | null | undefined;
  readonly entity_type: string | null | undefined;
  readonly id: string;
  readonly value: string | null | undefined;
}
